dmx.config({
  "resetar_senha": {
    "query": [
      {
        "type": "text",
        "name": "token"
      }
    ]
  }
});
